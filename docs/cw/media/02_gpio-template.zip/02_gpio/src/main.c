/*                                                                            *
 * B2M37AMP Microprocessor Applications                                       *
 *                                                                            *
 * Lab 02 template:                                                           *
 *   Goals:                                                                   *
 *    - familiarize with RCC                                                  *
 *    - configure and work with Generic Purpose Input Output (GPIO)           *
 *    - look into interrupt system (EXTI)                                     *
 *    - control 7segment display (SHCP PC12, DATA PC10, STCP PA15, OE PB1)    *
 *    - count button presses SW0 (PA0)                                        *
 *    - show button presses on display                                        *
 *                                                                            *
 *                                                                            *
 * Josef Krska 2026                                                           *
 */

#include "stm32f4xx.h"

#include <stdint.h>

uint32_t disp_digit = 0;
uint8_t digits[4] = { 0 };
uint8_t num2seg[] =
{
  0b00111111, /* 0 */
  0b00000110, /* 1 */
  0b01011011, /* 2 */
  0b01001111, /* 3 */
  0b01100110, /* 4 */
  0b01101101, /* 5 */
  0b01111101, /* 6 */
  0b00000111, /* 7 */
  0b01111111, /* 8 */
  0b01101111, /* 9 */
  [10] = 0b01111001, /* E */
};

void disp_shiftdata(uint16_t data)
{
  /* TODO: Ovladej STCP/CS */
  /* TODO: Nastav DATA/MOSI podle bitu promenne data, opakuj 16x */
  /* TODO: Na kazdy bit vygeneruj pulz na SHCP/SCK */
}

void display_setNumber(uint32_t num)
{
  /* TODO: Prevod cisla na segmenty */
}

void display_task(void)
{
  disp_shiftdata(num2seg[10]);

  ++disp_digit;
  if(disp_digit >= 4)
  {
    disp_digit = 0;
  }
}

uint32_t cnt = 0;

int main(void)
{
  /* Init */
  RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOBEN | RCC_AHB1ENR_GPIOCEN;

  RCC->AHB1ENR |= RCC_AHB1ENR_GPIOCEN; /* 4 = 1 << 2 */
 
  /* Nastav pin PC3 (LED4) do vystupniho rezimu */
  GPIOC->MODER &= ~(0x3 << (3*2));
  GPIOC->MODER |= 0x1 << (3*2);
 
  /* Dej na pin PC3 logickou 1 (3.3 V) a tim zapni LED */
  GPIOC->ODR |= 1 << 3;

  /* Display
       SCK  PC10
       CS   PA15
       MOSI PC12
       OE   PC9
       SRCLR PC8
       OE Buffer PB1
  */

  for(;;)
  {

  }
  return 0;
}
