/*                                                                            *
 * B2M37AMP Microprocessor Applications                                       *
 *                                                                            *
 * GPIO ovladac pro STM32F401                                                 *
 *                                                                            *
 *                                                                            *
 * gpio.c, Josef Krska 2026                                                   *
 */

#include "gpio.h"

void gpio_init(void)
{
  RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOBEN | RCC_AHB1ENR_GPIOCEN;
}

void gpio_setMode(GPIO_TypeDef* pg, uint32_t pin, uint32_t mode)
{
  pg->MODER &= ~(3UL << (pin * 2));
  pg->MODER |=  (mode << (pin * 2));
}

void gpio_setOutputType(GPIO_TypeDef* pg, uint32_t pin, uint32_t ot)
{
  if(ot)
  {
    pg->OTYPER |= (1 << pin);
  }
  else
  {
    pg->OTYPER &= ~(1 << pin);
  }
}

void gpio_setValue(GPIO_TypeDef* pg, uint32_t pin, uint32_t value)
{
  if(value)
  {
    pg->BSRR |= (1 << pin);
  }
  else
  {
    pg->BSRR |= (0x10000 << pin);
  }
}

uint32_t gpio_getValue(GPIO_TypeDef* pg, uint32_t pin)
{
  return pg->IDR & (1 << pin);
}

void gpio_setAlternativeFunction(GPIO_TypeDef* pg, uint32_t pin, uint32_t af)
{
  uint32_t afidx = 0;
  if(pin > 7)
  {
    afidx = 1;
    pin -= 8;
  }
  /* Clear current setting */
  pg->AFR[afidx] &= ~(0xFUL << (pin * 4));
  pg->AFR[afidx] |= (af & 0xF) << (pin * 4);
}

void exti_init(void)
{
  RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN;
}

void exti_enable(uint32_t pin, uint32_t enable)
{
  if(enable)
  {
    EXTI->IMR |= (1u << pin);
  }
  else
  {
    EXTI->IMR &= ~(1u << pin);
  }
}

void exti_configPin(GPIO_TypeDef* pg, uint32_t pin, uint32_t rising_trigger, uint32_t falling_trigger)
{
  if(rising_trigger)
  {
    EXTI->RTSR |= (1u << pin);
  }

  if(falling_trigger)
  {
    EXTI->FTSR |= (1u << pin);
  }

  uint32_t cridx = pin >> 2;
  pin &= 3;
  uint32_t gpioidx;
  if(pg == GPIOA) { gpioidx = 0; }
  else if (pg == GPIOB) { gpioidx = 1; }
  else if (pg == GPIOC) { gpioidx = 2; }
  else if (pg == GPIOD) { gpioidx = 3; }
  else if (pg == GPIOE) { gpioidx = 4; }
  else if (pg == GPIOH) { gpioidx = 7; }
  else { gpioidx = 15; }

  if(gpioidx != 15)
  {
    SYSCFG->EXTICR[cridx] &= ~(0xF << (pin * 4));
    SYSCFG->EXTICR[cridx] |= (gpioidx << (pin * 4));
  }
}

uint32_t exti_getPending(uint32_t pin)
{
  return (EXTI->PR & (1u << pin));
}

void exti_clearPending(uint32_t pin)
{
  EXTI->PR |= (1u << pin);
}
