/*                                                                            *
 * B2M37AMP Microprocessor Applications                                       *
 *                                                                            *
 * GPIO ovladac pro STM32F401                                                 *
 *                                                                            *
 *                                                                            *
 * gpio.h, Josef Krska 2026                                                   *
 */

#ifndef GPIO_H_HDR
#define GPIO_H_HDR

#include "stm32f4xx.h"
#include <stdint.h>

/** Inicializace ovladace **/
void gpio_init(void);

/** Nastaveni rezimu GPIO pinu
 *  \param pg ukazatel na GPIO periferii
 *  \param pin cislo pinu GPIO periferie (cislo mezi 0 az 15)
 *  \param mode rezim pinu, povolene hodnoty: 0 vstup, 1 vystup, 2 alternativni funkce, 3 analogovy mod
 **/
void gpio_setMode(GPIO_TypeDef* pg, uint32_t pin, uint32_t mode);

/** Nastaveni typu vystupu GPIO pinu
 *  \param pg ukazatel na GPIO periferii
 *  \param pin cislo pinu GPIO periferie (cislo mezi 0 az 15)
 *  \param ot typ vystupu, povolene hodnoty: 0 push-pull, 1 otevreny kolektor
 **/
void gpio_setOutputType(GPIO_TypeDef* pg, uint32_t pin, uint32_t ot);

/** Nastaveni vystupni hodnoty GPIO pinu
 *  \param pg ukazatel na GPIO periferii
 *  \param pin cislo pinu GPIO periferie (cislo mezi 0 az 15)
 *  \param value hodnota pinu, 0 pro nastaveni logicke nuly na vystup, value != 0 pro nastaveni logicke jednicky
 **/
void gpio_setValue(GPIO_TypeDef* pg, uint32_t pin, uint32_t value);

/** Cteni hodnoty na GPIO pinu
 *  \param pg ukazatel na GPIO periferii
 *  \param pin cislo pinu GPIO periferie (cislo mezi 0 az 15)
 *  \return 0 kdyz je na pinu logicka nula, != 0 kdyz je na pinu logicka jednicka
 **/
uint32_t gpio_getValue(GPIO_TypeDef* pg, uint32_t pin);

/** Nastaveni alternativni funkce GPIO pinu
 *  \param pg ukazatel na GPIO periferii
 *  \param pin cislo pinu GPIO periferie (cislo mezi 0 az 15)
 *  \param af cislo alternativni funkce, ktera je uvedena v datasheetu, af je v rozmezi 0 az 15
 **/
void gpio_setAlternativeFunction(GPIO_TypeDef* pg, uint32_t pin, uint32_t af);

/** Inicializace EXTI **/
void exti_init(void);

/** Aktivace/Deaktivace EXTI kanalu
 *  \param pin cislo EXTI kanalu, ktery ma byt zapnut ci vypnut (cislo mezi 0 az 15)
 *  \param enable pro enable == 0 bude kanal zakazan, pro enable != bude kanal povolen
 **/
void exti_enable(uint32_t pin, uint32_t enable);

/** Nastaveni sledovanych udalosti kanalu EXTI a pripojeni k GPIO pinu
 *  \param pg ukazatel na GPIO periferii
 *  \param pin cislo pinu GPIO periferie/cislo EXTI kanalu (cislo mezi 0 az 15)
 *  \param rising_trigger pro rising_trigger != 0 bude generovana udalost pri detekci nabezne hrany, pro rising_trigger == 0 nebude udalost generovana
 *  \param falling_trigger pro falling_trigger != 0 bude generovana udalost pri detekci sestupne hrany, pro falling_trigger == 0 nebude udalost generovana
 **/
void exti_configPin(GPIO_TypeDef* pg, uint32_t pin, uint32_t rising_trigger, uint32_t falling_trigger);

/** Cteni zdali doslo k nejake EXTI udalosti
 *  \param pin cislo EXTI kanalu (cislo mezi 0 az 15)
 *  \return 0 kdyz k zadne udalosti nedoslo, != 0 kdyz doslo k nejake sledovane udalosti
 **/
uint32_t exti_getPending(uint32_t pin);

/** Vycisteni pending bitu EXTI udalosti
 *  \param pin cislo EXTI kanalu (cislo mezi 0 az 15)
 **/
void exti_clearPending(uint32_t pin);

#endif /* GPIO_H_HDR */
