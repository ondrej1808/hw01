/*                                                                            *
 * B2M37AMP Microprocessor Applications                                       *
 *                                                                            *
 * Lab 02 template:                                                           *
 *   Goals:                                                                   *
 *    - get familiar with modular program design                              *
 *    - get familiar with TIMER peripheral and its modes of operation         *
 *    - generate signal using a TIMER on pin PWM_OUT (PA8, TIM_CH1)           *
 *    - utilize SYSTICK to execute periodic tasks                             *
 *    - implement morse code transmission                                     *
 *                                                                            *
 *   Work for home:                                                           *
 *    - generate an audible tone with a TIMER on pin BUZZER_OUT               *
 *      (PA11, TIM1_CH4)                                                      *
 *    - refactor functions for display control to a standalone module,        *
 *      devise a structure for the task data (as with the morse task)         *
 *    - (optionally) extend the morse code with more characters,              *
 *      e.g. numerals                                                         *
 *    - (optionally) use a TIMER to control the brightness of the segment     *
 *      display (look on the connections of U4)                               *
 *                                                                            *
 *                                                                            *
 * Josef Krska 2026                                                           *
 */

#include "stm32f4xx.h"

#include <stdint.h>
#include "gpio.h"

uint32_t disp_digit = 0;
uint8_t digits[4] = { 0 };
uint8_t num2seg[] =
{
  0b00111111, /* 0 */
  0b00000110, /* 1 */
  0b01011011, /* 2 */
  0b01001111, /* 3 */
  0b01100110, /* 4 */
  0b01101101, /* 5 */
  0b01111101, /* 6 */
  0b00000111, /* 7 */
  0b01111111, /* 8 */
  0b01101111, /* 9 */
  [10] = 0b01111001, /* E */
};

void disp_shiftdata(uint16_t data)
{
  /* Aktivuj STCP/CS */
  gpio_setValue(GPIOA, 15, 0);
  for(uint32_t idx = 0; idx < 16; ++idx)
  {
    /* Nastav DATA/MOSI podle bitu promenne data, opakuj 16x */
    gpio_setValue(GPIOC, 12, data & 0x8000);
    data <<= 1;
    /* Na kazdy bit vygeneruj pulz na SHCP/SCK */
    gpio_setValue(GPIOC, 10, 1);
    gpio_setValue(GPIOC, 10, 0);
  }
  /* Deaktivuj STCP/CS */
  gpio_setValue(GPIOA, 15, 1);
}

void display_task(void)
{
  disp_shiftdata((0x1000 << disp_digit) | digits[disp_digit]);

  ++disp_digit;
  if(disp_digit >= 4)
  {
    disp_digit = 0;
  }
}

void display_setNumber(uint32_t num)
{
  digits[3] = num2seg[num % 10];
  num /= 10;
  digits[2] = num2seg[num % 10];
  num /= 10;
  digits[1] = num2seg[num % 10];
  num /= 10;
  digits[0] = num2seg[num % 10];
}

uint32_t cnt = 0;

int main(void)
{
  /* Init */

  /* Display
       SCK  PC10
       CS   PA15
       MOSI PC12
       OE   PC9
       SRCLR PC8
       OE Buffer PB1
  */
  RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOBEN | RCC_AHB1ENR_GPIOCEN;

  /* LED4 PC3 */
  gpio_setMode(GPIOC, 3, 1);
  gpio_setValue(GPIOC, 3, 1);

  /* DISP STCP/CS */
  gpio_setMode(GPIOA, 15, 1);
  /* DISP SHCP/SCK */
  gpio_setMode(GPIOC, 10, 1);
  /* DISP DATA/MOSI */
  gpio_setMode(GPIOC, 12, 1);

  /* EXTI na stisk tlacitka PA0 */
  exti_configPin(GPIOA, 0, 1, 0);
  exti_enable(0, 1);

  /* TODO: nastav systick a casovac */

  /* Inicializuj ulohu morse */

  display_setNumber(cnt);
  for(;;)
  {
    if(exti_getPending(0))
    {
      exti_clearPending(0);
      ++cnt;
      display_setNumber(cnt);
    }

    display_task();
  }
  return 0;
}
